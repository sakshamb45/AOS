package conway_game;

public enum CellStatus {
	Dead,Alive;
}